package com.handroid.dovemessengerkt

data class User(
    val name: String,
    val email: String,
    val id: String,
    val avatarMockUpResource: Int,
    val avatarResource: Int
)